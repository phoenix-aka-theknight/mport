import { motion } from "framer-motion";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";
import { Calendar, BookOpen, Trophy, Target } from "lucide-react";

const timelineEvents = [
  {
    year: "2023",
    title: "Engineering Journey Begins",
    description: "Started BE in Computer Science Engineering at Jain College of Engineering and Technology, Hubli",
    icon: BookOpen,
    status: "completed",
    color: "text-green-400",
    bgColor: "bg-green-500/10",
    borderColor: "border-green-500/30"
  },
  {
    year: "2024",
    title: "Full Stack Development",
    description: "Co-founded Goblin Infotech, mastered modern web technologies, and launched multiple projects",
    icon: Trophy,
    status: "completed",
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/30"
  },
  {
    year: "2025",
    title: "Advanced Projects & Innovation",
    description: "Building cutting-edge AI/ML tools and expanding technical expertise across diverse technology stacks",
    icon: Target,
    status: "in-progress",
    color: "text-accent",
    bgColor: "bg-accent/10",
    borderColor: "border-accent/30"
  },
  {
    year: "2026",
    title: "Industry Integration",
    description: "Internships, industry collaborations, and real-world application of engineering principles",
    icon: Calendar,
    status: "upcoming",
    color: "text-muted-foreground",
    bgColor: "bg-muted/10",
    borderColor: "border-muted/30"
  },
  {
    year: "2027",
    title: "Engineering Graduate",
    description: "Expected completion of BE CSE degree, ready to make significant contributions to the tech industry",
    icon: Trophy,
    status: "upcoming",
    color: "text-muted-foreground",
    bgColor: "bg-muted/10",
    borderColor: "border-muted/30"
  }
];

export default function Timeline() {
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.2 });

  return (
    <div ref={ref} className="space-y-8">
      <motion.div
        className="text-center mb-12"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          Educational Journey
        </h3>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          My path through engineering, from inception to graduation and beyond
        </p>
      </motion.div>

      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary/50 via-accent/50 to-muted/20" />

        <div className="space-y-8">
          {timelineEvents.map((event, index) => {
            const IconComponent = event.icon;
            const isVisible = isIntersecting && index <= 2; // Show first 3 items when visible

            return (
              <motion.div
                key={event.year}
                className="relative flex items-start gap-6"
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ 
                  duration: 0.8, 
                  delay: index * 0.2,
                  ease: [0.25, 0.46, 0.45, 0.94] 
                }}
                viewport={{ once: true }}
              >
                {/* Timeline Node */}
                <motion.div
                  className={`relative z-10 flex items-center justify-center w-16 h-16 rounded-xl border-2 ${event.borderColor} ${event.bgColor} backdrop-blur-sm`}
                  whileHover={{ scale: 1.1 }}
                  animate={isVisible && event.status === 'in-progress' ? {
                    boxShadow: [
                      `0 0 20px ${event.color === 'text-accent' ? '#FF70D1' : '#6366f1'}40`,
                      `0 0 40px ${event.color === 'text-accent' ? '#FF70D1' : '#6366f1'}60`,
                      `0 0 20px ${event.color === 'text-accent' ? '#FF70D1' : '#6366f1'}40`
                    ]
                  } : {}}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <IconComponent className={`h-6 w-6 ${event.color}`} />
                </motion.div>

                {/* Content Card */}
                <motion.div
                  className={`flex-1 bg-card/70 backdrop-blur-sm border ${event.borderColor} rounded-xl p-6 ${event.status === 'in-progress' ? 'shadow-lg' : ''}`}
                  whileHover={{ y: -2, scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xl font-semibold">{event.title}</h4>
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${event.bgColor} ${event.color} border ${event.borderColor}`}>
                      {event.year}
                    </div>
                  </div>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {event.description}
                  </p>

                  {event.status === 'in-progress' && (
                    <motion.div 
                      className="mt-4 flex items-center gap-2"
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                    >
                      <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                      <span className="text-sm text-accent font-medium">Currently Active</span>
                    </motion.div>
                  )}

                  {event.status === 'completed' && (
                    <motion.div 
                      className="mt-4 flex items-center gap-2"
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5, type: "spring" }}
                    >
                      <div className="w-2 h-2 bg-green-400 rounded-full" />
                      <span className="text-sm text-green-400 font-medium">Completed</span>
                    </motion.div>
                  )}
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}