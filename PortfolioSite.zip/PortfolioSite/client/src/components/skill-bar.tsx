import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface SkillBarProps {
  skill: string;
  percentage: number;
  delay?: number;
  isVisible?: boolean;
}

export default function SkillBar({ skill, percentage, delay = 0, isVisible = false }: SkillBarProps) {
  const [animatedPercentage, setAnimatedPercentage] = useState(0);

  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setAnimatedPercentage(percentage);
      }, delay);
      return () => clearTimeout(timer);
    }
  }, [isVisible, percentage, delay]);

  return (
    <div className="space-y-2" data-testid={`skill-${skill.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">{skill}</span>
        <span className="text-sm text-muted-foreground">{percentage}%</span>
      </div>
      <div className="skill-bar">
        <motion.div 
          className="skill-progress"
          initial={{ width: 0 }}
          animate={{ width: isVisible ? `${animatedPercentage}%` : 0 }}
          transition={{ 
            duration: 2, 
            ease: "easeOut",
            delay: delay / 1000
          }}
        />
      </div>
    </div>
  );
}
