import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Calendar, Users, Zap } from "lucide-react";
import { magneticHover } from "@/lib/animations";

interface ProjectCardProps {
  title: string;
  description: string;
  image: string;
  technologies: string[];
  status: "completed" | "in-progress";
  githubUrl?: string;
  liveUrl?: string;
  delay?: number;
  year?: string;
  team?: string;
  category?: string;
}

export default function ProjectCard({
  title,
  description,
  image,
  technologies,
  status,
  githubUrl,
  liveUrl,
  delay = 0,
  year = "2024",
  team = "Solo",
  category = "Web Development"
}: ProjectCardProps) {
  return (
    <motion.div
      className="group project-card bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl overflow-hidden relative"
      initial={{ opacity: 0, y: 50, rotateX: 15 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 0.8, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      viewport={{ once: true }}
      whileHover={{ 
        y: -15, 
        rotateX: -5,
        boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)"
      }}
      style={{ 
        transformStyle: "preserve-3d",
        perspective: "1000px"
      }}
      data-testid={`project-card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      {/* Hover Gradient Overlay */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
        initial={false}
      />

      {/* Image Section */}
      <div className="relative overflow-hidden">
        <motion.img 
          src={image} 
          alt={title}
          className="w-full h-48 object-cover"
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        />
        
        {/* Image Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        
        {/* Status Badge */}
        <motion.div
          className="absolute top-4 right-4"
          initial={{ opacity: 0, scale: 0 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.3, type: "spring" }}
        >
          <Badge 
            variant={status === "completed" ? "default" : "secondary"}
            className={`
              ${status === "completed" 
                ? "bg-green-500/90 text-white border-green-400/50" 
                : "bg-blue-500/90 text-white border-blue-400/50"
              } 
              backdrop-blur-sm shadow-lg
            `}
          >
            <Zap className="h-3 w-3 mr-1" />
            {status === "completed" ? "Live" : "In Progress"}
          </Badge>
        </motion.div>

        {/* Project Meta Info */}
        <div className="absolute bottom-4 left-4 flex items-center gap-3 text-white/90 text-xs">
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            <span>{year}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            <span>{team}</span>
          </div>
        </div>
      </div>
      
      {/* Content Section */}
      <div className="p-6 space-y-4">
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <motion.h3 
              className="text-xl font-bold group-hover:text-primary transition-colors duration-300"
              whileHover={{ x: 2 }}
            >
              {title}
            </motion.h3>
          </div>
          
          <p className="text-sm text-primary/70 font-medium uppercase tracking-wide">
            {category}
          </p>
        </div>
        
        <p className="text-muted-foreground leading-relaxed text-sm">
          {description}
        </p>
        
        {/* Tech Stack */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Tech Stack</h4>
          <div className="flex flex-wrap gap-2">
            {technologies.map((tech, index) => (
              <motion.div
                key={tech}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: delay + 0.1 * index, type: "spring" }}
                whileHover={{ scale: 1.1, y: -2 }}
              >
                <Badge 
                  variant="outline" 
                  className="bg-primary/10 text-primary border-primary/30 hover:bg-primary/20 hover:border-primary/50 transition-all duration-300 cursor-pointer"
                >
                  {tech}
                </Badge>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="flex gap-3 pt-2">
          {githubUrl && (
            <motion.div {...magneticHover} className="flex-1">
              <Button 
                size="sm" 
                variant="outline" 
                className="w-full flex items-center justify-center gap-2 bg-transparent hover:bg-primary/10 border-primary/30 hover:border-primary/50 text-primary group/btn transition-all duration-300"
                data-testid={`github-link-${title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Github className="h-4 w-4 group-hover/btn:rotate-12 transition-transform duration-300" />
                Code
              </Button>
            </motion.div>
          )}
          {liveUrl && (
            <motion.div {...magneticHover} className="flex-1">
              <Button 
                size="sm" 
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-primary to-accent hover:from-accent hover:to-primary text-white group/btn shadow-lg hover:shadow-xl transition-all duration-300"
                data-testid={`live-link-${title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <ExternalLink className="h-4 w-4 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform duration-300" />
                Live Demo
              </Button>
            </motion.div>
          )}
        </div>
      </div>

      {/* Animated Corner Accent */}
      <motion.div
        className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-primary/20 to-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{ 
          clipPath: "polygon(100% 0%, 0% 100%, 100% 100%)"
        }}
      />
    </motion.div>
  );
}
