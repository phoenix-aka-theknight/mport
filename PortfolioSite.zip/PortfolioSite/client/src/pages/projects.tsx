import { motion } from "framer-motion";
import ProjectCard from "@/components/project-card";

const completedProjects = [
  {
    title: "School Suite",
    description: "Comprehensive school management system featuring attendance tracking and automated fee receipt generation. Built with modern web technologies for enhanced user experience.",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["React", "Node.js", "MySQL", "Express"],
    status: "completed" as const,
    githubUrl: "#",
    liveUrl: "#",
    year: "2024",
    team: "3 Members",
    category: "Education Tech"
  },
  {
    title: "Goblin Infotech Website",
    description: "Professional company website showcasing services and portfolio. Features modern design, responsive layouts, and optimized performance for enhanced user engagement.",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["React", "Vite", "Firebase", "CSS3"],
    status: "completed" as const,
    githubUrl: "#",
    liveUrl: "#",
    year: "2024",
    team: "Co-founder",
    category: "Business Website"
  }
];

const upcomingProjects = [
  {
    title: "Hyper-local Network Knowledge",
    description: "Revolutionary platform connecting local communities through shared knowledge and resources. Leveraging modern technologies to create meaningful local connections.",
    image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["React Native", "Firebase", "Node.js"],
    status: "in-progress" as const,
    year: "2025",
    team: "4 Members",
    category: "Social Platform"
  },
  {
    title: "AI Resume Builder",
    description: "Intelligent resume builder powered by AI to create professional, ATS-optimized resumes. Features smart content suggestions and industry-specific templates.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["React", "Python", "OpenAI"],
    status: "in-progress" as const,
    year: "2025",
    team: "Solo",
    category: "AI/ML Tool"
  }
];

export default function Projects() {
  return (
    <section className="section bg-secondary/30">
      <div className="max-w-7xl mx-auto w-full">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="projects-title">
            Featured Projects
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="projects-description">
            Showcasing innovative solutions built with modern technologies and best practices.
          </p>
        </motion.div>

        <div className="space-y-16">
          {/* Completed Projects */}
          <div>
            <motion.h3 
              className="text-2xl font-bold mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              data-testid="completed-projects-title"
            >
              Completed Projects
            </motion.h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {completedProjects.map((project, index) => (
                <ProjectCard
                  key={project.title}
                  {...project}
                  delay={index * 0.2}
                />
              ))}
            </div>
          </div>

          {/* Upcoming Projects */}
          <div>
            <motion.h3 
              className="text-2xl font-bold mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              data-testid="upcoming-projects-title"
            >
              Upcoming Projects
            </motion.h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {upcomingProjects.map((project, index) => (
                <ProjectCard
                  key={project.title}
                  {...project}
                  delay={index * 0.2}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
