import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";
import SkillBar from "@/components/skill-bar";
import { Code2, Server, Database, Zap, Trophy, Target } from "lucide-react";
import { magneticHover, glowEffect } from "@/lib/animations";

const skillCategories = [
  {
    title: "Frontend",
    icon: Code2,
    skills: [
      { name: "ReactJS", percentage: 90 },
      { name: "JavaScript", percentage: 85 },
      { name: "CSS/HTML", percentage: 88 },
      { name: "Vite", percentage: 80 },
    ]
  },
  {
    title: "Backend",
    icon: Server,
    skills: [
      { name: "Node.js", percentage: 85 },
      { name: "Java", percentage: 82 },
      { name: "Firebase", percentage: 88 },
      { name: "Kotlin", percentage: 75 },
    ]
  },
  {
    title: "Programming & DB",
    icon: Database,
    skills: [
      { name: "Python", percentage: 80 },
      { name: "MySQL", percentage: 85 },
      { name: "Supabase", percentage: 78 },
      { name: "REST APIs", percentage: 88 },
    ]
  }
];

export default function Skills() {
  const { ref, isIntersecting } = useIntersectionObserver({ threshold: 0.3 });

  return (
    <section className="section relative overflow-hidden" ref={ref}>
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.3, 0.5, 0.3],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 20, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 25, repeat: Infinity, delay: 5 }}
        />
      </div>

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Zap className="h-4 w-4" />
            Technical Expertise
          </motion.div>
          
          <h2 className="text-3xl md:text-5xl font-bold mb-6" data-testid="skills-title">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient">
              Skills & Technologies
            </span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg leading-relaxed" data-testid="skills-description">
            A comprehensive toolkit spanning modern web development, with expertise in both client and server-side technologies.
          </p>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          {[
            { icon: Trophy, value: "15+", label: "Technologies", color: "text-yellow-400" },
            { icon: Target, value: "4+", label: "Projects Completed", color: "text-green-400" },
            { icon: Zap, value: "2+", label: "Years Experience", color: "text-blue-400" },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 text-center"
              {...magneticHover}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 ${stat.color} mb-4`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, categoryIndex) => {
            const IconComponent = category.icon;
            return (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 50, rotateY: -15 }}
                whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
                transition={{ duration: 0.8, delay: categoryIndex * 0.2, ease: [0.25, 0.46, 0.45, 0.94] }}
                viewport={{ once: true }}
                whileHover={{ y: -10, rotateY: 5 }}
                style={{ transformStyle: "preserve-3d" }}
              >
                <Card 
                  className="group bg-card/70 backdrop-blur-sm border border-border/50 h-full relative overflow-hidden"
                  data-testid={`skill-category-${category.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {/* Hover Glow Effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    {...glowEffect}
                  />
                  
                  <CardContent className="p-6 relative z-10">
                    <div className="flex items-center gap-4 mb-8">
                      <motion.div 
                        className="relative"
                        whileHover={{ scale: 1.1, rotate: 10 }}
                        transition={{ duration: 0.3 }}
                      >
                        <div className="absolute inset-0 bg-primary/20 rounded-xl blur-xl" />
                        <div className="relative bg-gradient-to-br from-primary/20 to-accent/20 text-primary p-3 rounded-xl">
                          <IconComponent className="h-8 w-8" />
                        </div>
                      </motion.div>
                      <div>
                        <h3 className="text-xl font-bold group-hover:text-primary transition-colors duration-300">
                          {category.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {category.skills.length} Technologies
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-5">
                      {category.skills.map((skill, skillIndex) => (
                        <motion.div
                          key={skill.name}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ 
                            duration: 0.6, 
                            delay: isIntersecting ? skillIndex * 0.1 : 0,
                            ease: "easeOut" 
                          }}
                          viewport={{ once: true }}
                        >
                          <SkillBar
                            skill={skill.name}
                            percentage={skill.percentage}
                            delay={skillIndex * 200}
                            isVisible={isIntersecting}
                          />
                        </motion.div>
                      ))}
                    </div>

                    {/* Category Performance Indicator */}
                    <motion.div
                      className="mt-6 pt-4 border-t border-border/50"
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      transition={{ delay: 0.8 }}
                    >
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Overall Proficiency</span>
                        <span className="font-medium text-primary">
                          {Math.round(category.skills.reduce((acc, skill) => acc + skill.percentage, 0) / category.skills.length)}%
                        </span>
                      </div>
                    </motion.div>
                  </CardContent>

                  {/* Corner Accent */}
                  <motion.div
                    className="absolute bottom-0 right-0 w-16 h-16 bg-gradient-to-tl from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ clipPath: "polygon(100% 100%, 0% 100%, 100% 0%)" }}
                  />
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Call to Action */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <p className="text-muted-foreground mb-6">
            Interested in collaborating? Let's build something amazing together!
          </p>
          <motion.div {...magneticHover}>
            <motion.div
              className="inline-block"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <a href="/contact" className="bg-gradient-to-r from-primary to-accent text-white px-8 py-4 rounded-full font-medium hover:shadow-2xl transition-shadow duration-300 inline-block">
                Start a Conversation
              </a>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
