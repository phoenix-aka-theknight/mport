import { motion } from "framer-motion";
import ContactForm from "@/components/contact-form";
import { Mail, Github, MapPin, Building2 } from "lucide-react";

const contactInfo = [
  {
    icon: Mail,
    title: "Email",
    description: "manjunath.giraddi@example.com",
    href: "mailto:manjunath.giraddi@example.com"
  },
  {
    icon: Github,
    title: "GitHub",
    description: "github.com/phoenix-aka-theknight",
    href: "https://github.com/phoenix-aka-theknight"
  },
  {
    icon: MapPin,
    title: "Location",
    description: "Hubli, Karnataka, India",
    href: null
  },
  {
    icon: Building2,
    title: "Company",
    description: "Co-founder, Goblin Infotech",
    href: null
  }
];

export default function Contact() {
  return (
    <section className="section">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="contact-title">
            Let's Connect
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="contact-description">
            Ready to collaborate on your next project? Let's discuss how we can bring your ideas to life.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-semibold mb-6" data-testid="contact-info-title">
              Get in Touch
            </h3>
            <div className="space-y-6">
              {contactInfo.map((info, index) => {
                const IconComponent = info.icon;
                const content = (
                  <motion.div
                    key={info.title}
                    className="flex items-center space-x-4"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    data-testid={`contact-info-${info.title.toLowerCase()}`}
                  >
                    <div className="bg-primary/20 text-primary p-3 rounded-lg">
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-medium">{info.title}</p>
                      <p className="text-muted-foreground text-sm">{info.description}</p>
                    </div>
                  </motion.div>
                );

                return info.href ? (
                  <a 
                    key={info.title}
                    href={info.href}
                    className="block hover:text-primary transition-colors"
                    target={info.href.startsWith('http') ? '_blank' : undefined}
                    rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  >
                    {content}
                  </a>
                ) : content;
              })}
            </div>
          </motion.div>

          <ContactForm />
        </div>
      </div>
    </section>
  );
}
