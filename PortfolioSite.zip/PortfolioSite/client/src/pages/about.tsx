import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Building2 } from "lucide-react";
import Timeline from "@/components/timeline";

export default function About() {
  return (
    <section className="section bg-secondary/30 relative overflow-hidden">
      {/* Ambient Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-1/3 right-1/4 w-80 h-80 bg-primary/3 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.4, 1],
            opacity: [0.2, 0.4, 0.2],
            x: [0, 30, 0],
          }}
          transition={{ duration: 15, repeat: Infinity }}
        />
      </div>

      <div className="max-w-7xl mx-auto w-full relative z-10">
        {/* Main About Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -50, rotateY: -15 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            transition={{ duration: 1, ease: [0.25, 0.46, 0.45, 0.94] }}
            viewport={{ once: true }}
            style={{ transformStyle: "preserve-3d" }}
          >
            <div className="relative group">
              {/* Glow effect behind image */}
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-accent/20 rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-opacity duration-700" />
              
              <motion.img 
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern tech office environment with glass walls and modern design" 
                className="relative z-10 rounded-2xl shadow-2xl w-full h-auto group-hover:scale-105 transition-transform duration-700"
                data-testid="about-image"
                whileHover={{ rotateY: 5, rotateX: -2 }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <motion.div
              className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Building2 className="h-4 w-4" />
              Getting to know me
            </motion.div>

            <h2 className="text-3xl md:text-5xl font-bold mb-6" data-testid="about-title">
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient">
                About Me
              </span>
            </h2>
            
            <p className="text-muted-foreground mb-6 leading-relaxed text-lg" data-testid="about-description-1">
              I'm a passionate Full Stack Developer currently pursuing my BE in Computer Science Engineering 
              at Jain College of Engineering and Technology, Hubli. As the Co-founder of Goblin Infotech, 
              I'm dedicated to creating innovative digital solutions that make a difference.
            </p>
            
            <p className="text-muted-foreground mb-8 leading-relaxed text-lg" data-testid="about-description-2">
              My journey in technology spans across multiple domains - from elegant frontend experiences with React 
              to robust backend solutions with Node.js and Firebase. I believe in continuous learning and applying 
              cutting-edge technologies to solve real-world challenges.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 30, rotateX: 15 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
                whileHover={{ y: -5, rotateX: -2 }}
              >
                <Card className="bg-card/70 backdrop-blur-sm border-border/50 group hover:border-primary/30 transition-all duration-300" data-testid="education-card">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="bg-gradient-to-r from-primary/20 to-accent/20 text-primary p-3 rounded-xl group-hover:scale-110 transition-transform duration-300">
                        <GraduationCap className="h-6 w-6" />
                      </div>
                      <h3 className="font-bold text-primary text-lg">Education</h3>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">
                      BE CSE 3rd Year<br />
                      Jain College of Engineering, Hubli
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 30, rotateX: 15 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                viewport={{ once: true }}
                whileHover={{ y: -5, rotateX: -2 }}
              >
                <Card className="bg-card/70 backdrop-blur-sm border-border/50 group hover:border-accent/30 transition-all duration-300" data-testid="role-card">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="bg-gradient-to-r from-accent/20 to-primary/20 text-accent p-3 rounded-xl group-hover:scale-110 transition-transform duration-300">
                        <Building2 className="h-6 w-6" />
                      </div>
                      <h3 className="font-bold text-accent text-lg">Role</h3>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">
                      Co-founder<br />
                      Goblin Infotech
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Timeline Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <Timeline />
        </motion.div>
      </div>
    </section>
  );
}
